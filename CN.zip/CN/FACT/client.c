#include<stdio.h>
#include<winsock2.h>
#pragma comment(lib,"ws2_32.lib") //Winsock Library

void func(SOCKET sockfd);

int main()
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in servaddr;

    printf("\nInitializing Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }
    printf("Initialized.\n");

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == INVALID_SOCKET) {
        printf("Could not create socket : %d" , WSAGetLastError());
    }
    printf("Socket created.\n");

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(43451);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to server
    if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        printf("Connection failed with error code : %d" , WSAGetLastError());
        return 1;
    }
    printf("Connected to server.\n");

    // Handle the interaction
    func(sockfd);

    // Close the socket
    closesocket(sockfd);
    WSACleanup();

    return 0;
}

// Function to send number to server and receive factorial result
void func(SOCKET sockfd)
{
    int n;
    unsigned long long fact;

    // Input the number for factorial calculation
    printf("Enter the number to calculate its factorial: ");
    scanf("%d", &n);

    // Send the number to the server
    send(sockfd, (char*)&n, sizeof(n), 0);

    // Receive the factorial result from server
    recv(sockfd, (char*)&fact, sizeof(fact), 0);

    // Print the received result
    printf("Factorial of %d is: %llu\n", n, fact);
}
