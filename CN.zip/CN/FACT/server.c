#include<stdio.h>
#include<winsock2.h>
#pragma comment(lib,"ws2_32.lib") //Winsock Library

// Function to calculate factorial
unsigned long long factorial(int n) {
    unsigned long long fact = 1;
    for(int i = 1; i <= n; ++i) {
        fact *= i;
    }
    return fact;
}

void func(SOCKET confd);

int main()
{
    WSADATA wsa;
    SOCKET sockfd, confd;
    struct sockaddr_in servaddr, cliaddr;
    int len;

    printf("\nInitializing Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) {
        printf("Failed. Error Code : %d", WSAGetLastError());
        return 1;
    }
    printf("Initialized.\n");

    // Create socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == INVALID_SOCKET) {
        printf("Could not create socket : %d" , WSAGetLastError());
        return 1;
    }
    printf("Socket created.\n");

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(43451);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Bind
    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == SOCKET_ERROR) {
        printf("Bind failed with error code : %d" , WSAGetLastError());
        return 1;
    }
    printf("Bind done.\n");

    // Listen
    listen(sockfd, 5);
    printf("Listening...\n");

    len = sizeof(cliaddr);
    // Accept connection
    confd = accept(sockfd, (struct sockaddr *)&cliaddr, &len);
    if (confd == INVALID_SOCKET) {
        printf("Accept failed with error code : %d" , WSAGetLastError());
        return 1;
    }
    printf("Client accepted.\n");

    // Handle the client request
    func(confd);

    // Close the socket
    closesocket(confd);
    closesocket(sockfd);
    WSACleanup();

    return 0;
}

// Function to receive the number and send the factorial result
void func(SOCKET confd)
{
    int n;
    unsigned long long fact;

    // Receive the number from client
    recv(confd, (char*)&n, sizeof(n), 0);
    printf("Number received from client: %d\n", n);

    // Calculate factorial
    fact = factorial(n);
    printf("Factorial of %d is %llu\n", n, fact);

    // Send the result back to the client
    send(confd, (char*)&fact, sizeof(fact), 0);
}
