#include<stdio.h>
#include<winsock2.h>
#pragma comment(lib,"ws2_32.lib") //Winsock Library

void func(SOCKET sockfd);

int main()
{
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in servaddr;

    printf("\nInitializing Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
    printf("Initialized.\n");

    // Create socket
    sockfd = socket(AF_INET , SOCK_STREAM , 0 );
    if (sockfd == INVALID_SOCKET) {
        printf("Could not create socket : %d" , WSAGetLastError());
    }
    printf("Socket created.\n");

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(43451);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to server
    if (connect(sockfd , (struct sockaddr *)&servaddr , sizeof(servaddr)) < 0) {
        printf("Connection failed with error code : %d" , WSAGetLastError());
        return 1;
    }
    printf("Connected to server.\n");

    // Handle the interaction
    func(sockfd);

    // Close the socket
    closesocket(sockfd);
    WSACleanup();

    return 0;
}

void func(SOCKET sockfd)
{
    int p, n, r, total;

    printf("Enter the value for principal (p): ");
    scanf("%d", &p);
    send(sockfd, (char*)&p, sizeof(p), 0);

    printf("Enter the value for years (n): ");
    scanf("%d", &n);
    send(sockfd, (char*)&n, sizeof(n), 0);

    printf("Enter the value for rate (r): ");
    scanf("%d", &r);
    send(sockfd, (char*)&r, sizeof(r), 0);

    recv(sockfd, (char*)&total, sizeof(total), 0);
    printf("The calculated interest amount is: %d\n", total);
}
