#include<stdio.h>
#include<winsock2.h>
#pragma comment(lib,"ws2_32.lib") //Winsock Library

void func(SOCKET confd);

int main()
{
    WSADATA wsa;
    SOCKET sockfd, confd;
    struct sockaddr_in servaddr, cliaddr;
    int len;

    printf("\nInitializing Winsock...");
    if (WSAStartup(MAKEWORD(2,2),&wsa) != 0) {
        printf("Failed. Error Code : %d",WSAGetLastError());
        return 1;
    }
    printf("Initialized.\n");

    // Create socket
    sockfd = socket(AF_INET , SOCK_STREAM , 0 );
    if (sockfd == INVALID_SOCKET) {
        printf("Could not create socket : %d" , WSAGetLastError());
        return 1;
    }
    printf("Socket created.\n");

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(43451);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Bind
    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == SOCKET_ERROR) {
        printf("Bind failed with error code : %d" , WSAGetLastError());
        return 1;
    }
    printf("Bind done.\n");

    // Listen
    listen(sockfd, 5);
    printf("Listening...\n");

    len = sizeof(cliaddr);
    // Accept connection
    confd = accept(sockfd, (struct sockaddr *)&cliaddr, &len);
    if (confd == INVALID_SOCKET) {
        printf("Accept failed with error code : %d" , WSAGetLastError());
        return 1;
    }
    printf("Client accepted.\n");

    // Handle the client request
    func(confd);

    // Close the socket
    closesocket(confd);
    closesocket(sockfd);
    WSACleanup();

    return 0;
}

void func(SOCKET confd)
{
    int p, n, r, total;

    printf("Receiving values from client...\n");
    
    recv(confd, (char*)&p, sizeof(p), 0);
    printf("Principal (p): %d\n", p);

    recv(confd, (char*)&n, sizeof(n), 0);
    printf("Years (n): %d\n", n);

    recv(confd, (char*)&r, sizeof(r), 0);
    printf("Rate (r): %d\n", r);

    total = (p * n * r) / 100;
    printf("Total interest: %d\n", total);

    send(confd, (char*)&total, sizeof(total), 0);
}
