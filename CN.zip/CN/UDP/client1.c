#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>  // Include Winsock2 for Windows UDP sockets
#pragma comment(lib,"ws2_32.lib") // Link with ws2_32.lib for socket functionality

#define PORT 43451
#define BUFLEN 1024

void generateFibonacci(int n, char* buffer) {
    int a = 0, b = 1, next;
    sprintf(buffer, "Client 1 Fibonacci Series: ");
    for (int i = 0; i < n; i++) {
        sprintf(buffer + strlen(buffer), "%d ", a);
        next = a + b;
        a = b;
        b = next;
    }
}

int main() {
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in servaddr;
    char buffer[BUFLEN];
    int addr_len;

    // Initialize Winsock
    printf("\nInitializing Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("Failed. Error Code: %d", WSAGetLastError());
        return 1;
    }
    printf("Initialized.\n");

    // Create a UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == INVALID_SOCKET) {
        printf("Socket creation failed: %d", WSAGetLastError());
        WSACleanup();
        return 1;
    }
    printf("UDP client 1 socket created.\n");

    // Initialize server address
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Generate the first 5 Fibonacci numbers
    generateFibonacci(5, buffer);

    // Display the Fibonacci series on the client side
    printf("%s\n", buffer);

    // Send the Fibonacci series to the server
    sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr*)&servaddr, sizeof(servaddr));
    printf("Client 1: Fibonacci series sent to server.\n");

    // Receive the server's acknowledgment
    addr_len = sizeof(servaddr);
    recvfrom(sockfd, buffer, BUFLEN, 0, (struct sockaddr*)&servaddr, &addr_len);
    buffer[recvfrom(sockfd, buffer, BUFLEN, 0, (struct sockaddr*)&servaddr, &addr_len)] = '\0';
    printf("Client 1: Server's acknowledgment: %s\n", buffer);

    // Close the socket
    closesocket(sockfd);
    WSACleanup();

    return 0;
}
