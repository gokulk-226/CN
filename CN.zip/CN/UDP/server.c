#include <stdio.h>
#include <winsock2.h>
#include <pthread.h>  // Include pthread for multithreading
#pragma comment(lib, "ws2_32.lib")  // Link with ws2_32.lib for socket functionality

#define PORT 43451
#define BUFLEN 1024

void* handleClient(void* arg) {
    SOCKET sockfd = *((SOCKET*)arg);
    struct sockaddr_in cliaddr;
    int len = sizeof(cliaddr);
    char buffer[BUFLEN];

    // Receive a message from the client
    recvfrom(sockfd, buffer, BUFLEN, 0, (struct sockaddr*)&cliaddr, &len);
    printf("Received Fibonacci series from client: %s\n", buffer);

    // Send an acknowledgment back to the client
    char response[] = "Fibonacci series received!";
    sendto(sockfd, response, strlen(response), 0, (struct sockaddr*)&cliaddr, len);
    printf("Acknowledgment sent to client.\n");

    return NULL;
}

int main() {
    WSADATA wsa;
    SOCKET sockfd;
    struct sockaddr_in servaddr;

    // Initialize Winsock
    printf("\nInitializing Winsock...");
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("Failed. Error Code: %d", WSAGetLastError());
        return 1;
    }
    printf("Initialized.\n");

    // Create a UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd == INVALID_SOCKET) {
        printf("Socket creation failed: %d", WSAGetLastError());
        WSACleanup();
        return 1;
    }
    printf("UDP server socket created.\n");

    // Initialize server address and bind
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        printf("Bind failed with error code: %d", WSAGetLastError());
        closesocket(sockfd);
        WSACleanup();
        return 1;
    }
    printf("Bind successful. Waiting for clients...\n");

    while (1) {
        pthread_t client_thread;

        // Spawn a new thread to handle each client request
        if (pthread_create(&client_thread, NULL, handleClient, &sockfd) != 0) {
            printf("Error creating thread\n");
            closesocket(sockfd);
            WSACleanup();
            return 1;
        }

        // Detach the thread to allow independent execution
        pthread_detach(client_thread);
    }

    // Close the socket
    closesocket(sockfd);
    WSACleanup();
    return 0;
}
